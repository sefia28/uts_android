package com.example.uts_android_sefia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.net.Uri;
import android.os.Bundle;
import android.util.Half;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class DataDetail extends AppCompatActivity {
    ProgressBar pb;
    EditText etID,etNama, etDeskripsi, etWarna, etUkuran, etHarga, etStok;
    Button btHapus, btUbah;
    String id, nama, deskripsi, warna, ukuran, harga, stok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_detail);

        pb = (ProgressBar) findViewById(R.id.pb);
        etID = (EditText) findViewById(R.id.et_id);
        etNama = (EditText) findViewById(R.id.et_nama);
        etDeskripsi = (EditText) findViewById(R.id.et_deskripsi);
        etWarna = (EditText) findViewById(R.id.et_warna);
        etUkuran = (EditText) findViewById(R.id.et_ukuran);
        etHarga = (EditText) findViewById(R.id.et_harga);
        etStok = (EditText) findViewById(R.id.et_stok);

        btUbah = (Button) findViewById(R.id.bt_ubah);
        btHapus = (Button) findViewById(R.id.bt_hapus);

        //tombol back
        getSupportActionBar().setTitle("Detail Barang"); // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // for add back arrow in action back

        //tangkap bundle
        Bundle bundle = null;
        bundle = this.getIntent().getExtras();

        //letakkan isi bundle
        id = bundle.getString("b_id");
        nama = bundle.getString("b_nama");
        deskripsi = bundle.getString("b_deskripsi");
        warna = bundle.getString("b_warna");
        ukuran = bundle.getString("b_ukuran");
        harga = bundle.getString("b_harga");
        stok = bundle.getString("b_stok");

        //letakkan pada textview
        etID.setText(id);
        etNama.setText(nama);
        etDeskripsi.setText(deskripsi);
        etWarna.setText(warna);
        etUkuran.setText(ukuran);
        etHarga.setText(harga);
        etStok.setText(stok);

        //operasi ubah data

        btUbah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama =  etNama.getText().toString();
                deskripsi =  etDeskripsi.getText().toString();
                warna =  etWarna.getText().toString();
                ukuran =  etUkuran.getText().toString();
                harga =  etHarga.getText().toString();
                stok =  etStok.getText().toString();


                pb.setVisibility(ProgressBar.VISIBLE); //munculkan progressbar

                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url = "https://sefiatriwd.000webhostapp.com/api/produk.php?action=ubah&id="+id+"&nama="+nama+"&deskripsi="+deskripsi+"&warna="+warna+"&ukuran="+ukuran+"&harga="+harga+"&stok="+stok;

                Log.d("Hendro ", "onClick: " + url);
                JsonObjectRequest jsObjRequest = new JsonObjectRequest(
                        Request.Method.POST,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {
                                String id, nama, deskripsi, warna, ukuran, harga, stok;

                                if (response.optString("result").equals("true")){
                                    Toast.makeText(getApplicationContext(), "Data terubah!", Toast.LENGTH_SHORT).show();

                                    finish(); //tutup activity
                                }else{
                                    Toast.makeText(getApplicationContext(), "O ow, sepertinya harus dicoba lagi", Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(ProgressBar.GONE); //sembunyikan progress bar
                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d("Events: ", error.toString());

                        Toast.makeText(getApplicationContext(), "Hmm, masalah internet atau data yang kamu masukkan", Toast.LENGTH_SHORT).show();

                        pb.setVisibility(ProgressBar.GONE); //sembunyikan progress bar
                    }
                });

                queue.add(jsObjRequest);
            }
        });

        btHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pb.setVisibility(ProgressBar.VISIBLE); //tampilkan progress bar

                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url = "https://sefiatriwd.000webhostapp.com/api/produk.php?action=hapus&id="+ id;

                JsonObjectRequest jsObjRequest = new JsonObjectRequest(
                        Request.Method.POST,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {

                                if (response.optString("result").equals("true")){
                                    Toast.makeText(getApplicationContext(), "Data terhapus!", Toast.LENGTH_SHORT).show();

                                    finish(); //tutup activity
                                }else{
                                    Toast.makeText(getApplicationContext(), "O ow, sepertinya harus dicoba lagi", Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(ProgressBar.GONE); //sembunyikan progress bar
                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d("Events: ", error.toString());

                        pb.setVisibility(ProgressBar.GONE); //sembunyikan progress bar

                        Toast.makeText(getApplicationContext(), "Hmm, masalah internet atau data yang kamu masukkan", Toast.LENGTH_SHORT).show();
                    }
                });

                queue.add(jsObjRequest);
            }
        });
    }

}