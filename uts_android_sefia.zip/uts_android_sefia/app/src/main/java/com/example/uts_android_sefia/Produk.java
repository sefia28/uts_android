package com.example.uts_android_sefia;

public class Produk {
    String id, nama, deskripsi, warna, ukuran, harga, stok;

    public Produk(String id, String nama, String deskripsi, String warna, String ukuran, String harga, String stok) {
        this.id = id;
        this.nama = nama;
        this.deskripsi = deskripsi;
        this.warna = warna;
        this.ukuran = ukuran;
        this.harga = harga;
        this.stok = stok;

    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getWarna() {
        return warna;
    }

    public String getUkuran() {
        return ukuran;
    }

    public String getHarga() {
        return harga;
    }

    public String getStok() {
        return stok;
    }

}
